//1. Создать пустой проект в IntelliJ IDEA и прописать метод main();

package ru.geekbrains.java.javaone.homework.LessonOne;

public class TaskOne {
    public static void main(String[] args) {
        System.out.println("Первое задание.");
    }
}