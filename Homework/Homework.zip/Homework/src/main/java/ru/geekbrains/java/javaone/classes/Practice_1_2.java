package ru.geekbrains.java.javaone.classes;

public class Practice_1_2 {
    public static void main(String[] args) {
        System.out.println("Main method works");

    }
    public static 
}
