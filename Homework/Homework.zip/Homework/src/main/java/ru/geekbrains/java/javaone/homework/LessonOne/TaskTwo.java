//2. Создать переменные всех пройденных типов данных, и инициализировать их значения;

package ru.geekbrains.java.javaone.homework.LessonOne;

public class TaskTwo {
    public static void main(String[] args) {
        byte byteValue = -120;
        short shortValue = 14000;
        int intValue = 15748;
        long longValue = 579351264720L;
        float floatValue = 144.58f;
        double doubleVal= 158.956;
        char charVal = '!';
        boolean booVal = false;

        System.out.println("byte = " + byteValue);
        System.out.println("short = " + shortValue);
        System.out.println("int = " + intValue);
        System.out.println("long = " + longValue);
        System.out.println("float = " + floatValue);
        System.out.println("double = " + doubleVal);
        System.out.println("char = " + charVal);
        System.out.println("boolean = " + booVal);
    }
}
